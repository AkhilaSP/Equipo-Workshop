<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Physicians extends Model
{
    protected $fillable = [
        'name', 'contact', 
    ];
}
