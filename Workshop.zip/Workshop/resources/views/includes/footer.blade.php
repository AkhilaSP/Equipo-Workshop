<footer class="footer"style="margin-top:100px">
               
    Copyright © <script>document.write(new Date().getFullYear())</script> Equipo Health All rights reserved. 
                     
</footer>